#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <assert.h>
#include <pthread.h>
#include <semaphore.h>
#include <signal.h>       

//At most you can have CMAX threads for producers or consumers
#define CMAX (10) 

pthread_cond_t empty  = PTHREAD_COND_INITIALIZER;
pthread_cond_t fill   = PTHREAD_COND_INITIALIZER;
pthread_mutex_t m     = PTHREAD_MUTEX_INITIALIZER;

// Define global variables here







/* ==================================================== */
/* SIGNAL INTERRUPT HANDLER (Catches the SIGINT signal) */
/* ==================================================== */
int stopFlag = 0; // Flag for signaling other threads to stop running.
void handler(int signo)
{
	if(signo == SIGINT) {
		printf(" Stopping...\n");
		stopFlag = 1;
	}
}

void
Pthread_mutex_lock(pthread_mutex_t *m)
{
    int rc = pthread_mutex_lock(m);
    assert(rc == 0);
}
                                                                                
void
Pthread_mutex_unlock(pthread_mutex_t *m)
{
    int rc = pthread_mutex_unlock(m);
    assert(rc == 0);
}
                                                                                
void
Pthread_create(pthread_t *thread, const pthread_attr_t *attr, 	
	       void *(*start_routine)(void*), void *arg)
{
    int rc = pthread_create(thread, attr, start_routine, arg);
    assert(rc == 0);
}

void
Pthread_join(pthread_t thread, void **value_ptr)
{
    int rc = pthread_join(thread, value_ptr);
    assert(rc == 0);
}

void do_fill(int value) 
{
//Implement fill operations here
//Fill one item each time

}

int do_get()
{
//Implement get item here, remove one item each time
// Return the value consumed by the consumer


}

void *
producer(int *arg)
{
    while (!stopFlag) { 
    //Implement producer mutex and CVs here
    //Should print a message:  Producer x  fills y  
    
    
    
    }

    if(stopFlag == 1){ //end case
    // Gracefully quit the program when CTRL + c
    // At this time, only fill -1 to the buffer
    //Should print a message:  Producer x  fills -1  
    
    
    
    
    
    
    
    
    }

    return NULL;
}
                                                                               
void *
consumer(int *arg)
{
    while (!stopFlag) { 
    //Implement producer mutex and CVs here
    //Should print a message: Consumer x removes y  
    
    
    
    
    }
    return NULL;
}

int
main(int argc, char *argv[])
{
    if (argc != 4) {
	fprintf(stderr, "usage: %s <buffersize> <producers> <consumers>\n", argv[0]);
	exit(1);
    }
    //Implement initilization here
   



    /* ----------------------- */
    /* REGISTER SIGNAL HANDLER */
    /* ----------------------- */
    signal(SIGINT, handler);
    
    
    //Create producer threads and consumer threads here
    
    
    


    //Join producer and consumer threads here
    



    
    // Destroy the (by now unlocked) mutex lock.
    
   
    // Destroy CV fill.
    
    
    // Destroy CV empty.
    
    exit(0);
}

