#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <assert.h>
#include <pthread.h>
#include <semaphore.h>
#include <signal.h>       

//At most you can have CMAX threads for producers or consumers
#define CMAX (10) 
sem_t empty;
sem_t full;
sem_t mutex;

//Define global variables here











/* ==================================================== */
/* SIGNAL INTERRUPT HANDLER (Catches the SIGINT signal) */
/* ==================================================== */
void handler(int signo)
{
	if(signo == SIGINT) {
		printf(" Stopping...\n");
		stopFlag = 1;
	}
}


void
Pthread_mutex_lock(pthread_mutex_t *m)
{
    int rc = pthread_mutex_lock(m);
    assert(rc == 0);
}
                                                                                
void
Pthread_mutex_unlock(pthread_mutex_t *m)
{
    int rc = pthread_mutex_unlock(m);
    assert(rc == 0);
}
                                                                                
void
Pthread_create(pthread_t *thread, const pthread_attr_t *attr, 	
	       void *(*start_routine)(void*), void *arg)
{
    int rc = pthread_create(thread, attr, start_routine, arg);
    assert(rc == 0);
}

void
Pthread_join(pthread_t thread, void **value_ptr)
{
    int rc = pthread_join(thread, value_ptr);
    assert(rc == 0);
}

void
Sem_init(sem_t *sem, unsigned int value) 
{
    int rc = sem_init(sem, 0, value);
    assert(rc == 0);
}

void Sem_wait(sem_t *sem) 
{
    int rc = sem_wait(sem);
    assert(rc == 0);
}

void Sem_post(sem_t *sem) 
{
    int rc = sem_post(sem);
    assert(rc == 0);
}


void do_fill(int value) 
{
//Implement fill operations here, fill one item per time 



}

int do_get()
{
//Implement get operations here, remove one item per time 




}

void *
producer(int * arg)
{
    int i;
    while (!stopFlag) {
    //Use semphores to produce an item here
    //print a message: producer x fills y
    

    
    
    
    }

    // end case
    if(stopFlag == 1){
    // Gracefully quit the program when CTRL + c
    // At this time, only fill -1 to the buffer
    //Should print a message:  Producer x  fills -1  
    
    
    
    
    
    
    
    }
    return NULL;
}
                                                                               
void *
consumer(int * arg)
{
    while (!stopFlag) {
    //Use semphores to consume an item here
    //print a message: consumer  x removes y
    
    
    
    }
    return NULL;
}

void 
main(int argc, char *argv[])
{
    if (argc != 4) {
	fprintf(stderr, "usage: %s <buffersize> <producers> <consumers>\n", argv[0]);
	exit(1);
    }
   //variables initlization here




    signal(SIGINT, handler);
    
    //Initializing semphores here




    //Start running producer and consumer threads here
   




    //Join producer and consumer thread here
  



    // Destroy semphores here
   



    exit(0);
}

